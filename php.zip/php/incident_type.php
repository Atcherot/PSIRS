<?php
header('Content-Type: text/plain'); // Plain text response

$servername = "localhost";  // Database server
$username = "publ_PSIRS";   // Database username
$password = "M1IOl+7Az3ArG5ld"; // Database password
$dbname = "publ_incident_reporting_system"; // Database name
$socket = '/run/mysqld/mysqld.sock';

// Create connection
$mysqli = new mysqli($servername, $username, $password, $dbname, null, $socket);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$report_id = isset($_GET['report_id']) ? intval($_GET['report_id']) : null;

if ($report_id) {
    $sql = "SELECT incident_type FROM incident_type_logs WHERE report_id = ?";
    $stmt = $mysqli->prepare($sql);

    if (!$stmt) {
        echo "Error preparing statement: " . $mysqli->error;
        exit;
    }

    $stmt->bind_param("i", $report_id);
    $stmt->execute();
    $stmt->bind_result($incident_type);
    $stmt->fetch();
    $stmt->close();

    echo $incident_type ? "Incident Type: $incident_type" : "Incident type not found";

    $instructions = [
    'Burn' => "For burns:\n
Step 1: Cool the burn with running water for at least 10 minutes.\n
Step 2: Cover the burn with a clean, non-fluffy cloth or sterile dressing.\n
Step 3: Avoid applying ice, creams, or oils.\n
Step 4: Seek medical help if the burn is severe or covers a large area.",

    'Fracture' => "For fractures:\n
Step 1: Keep the injured area still and supported to prevent movement.\n
Step 2: Apply ice wrapped in a cloth to reduce swelling.\n
Step 3: Avoid moving the injured person unless necessary.\n
Step 4: Seek medical help immediately.",

    'Bleeding' => "For bleeding:\n
Step 1: Apply firm, steady pressure to the wound using a clean cloth.\n
Step 2: Elevate the injured area if possible, unless it causes more pain.\n
Step 3: Keep applying pressure until bleeding stops.\n
Step 4: Seek medical help if bleeding does not stop or is severe.",

    'Heart Attack' => "For a heart attack:\n
Step 1: Keep the person calm and seated comfortably.\n
Step 2: If not allergic, give the person aspirin to chew slowly.\n
Step 3: Monitor their breathing and be ready to perform CPR if needed.",

    'Stroke' => "For a stroke:\n
Step 1: Keep the person comfortable and supported.\n
Step 2: Do not give them food or drink.\n
Step 3: Note the time symptoms started and share it with medical professionals.",

    'Seizure' => "For a seizure:\n
Step 1: Stay calm and clear the area to prevent injury.\n
Step 2: Cushion their head and turn them on their side.\n
Step 3: Do not restrain or put anything in their mouth.\n
Step 4: Call emergency services if the seizure lasts longer than 5 minutes or if the person is injured.",

    'Injury' => "For an injury:\n
Step 1: Stop the bleeding by applying direct pressure.\n
Step 2: Clean wounds gently with water and disinfect if possible.\n
Step 3: Immobilize injured limbs using a splint or cloth.\n
Step 4: Seek medical help if the injury is severe or there are signs of infection."
];


    echo "\n" . ($instructions[$incident_type] ?? "No instructions available for this type.");
} else {
    echo "No report ID provided.";
}

$mysqli->close();
?>
