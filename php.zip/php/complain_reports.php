<?php
session_start(); // Start session para sa report_id
include 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reason = isset($_POST['reason']) ? htmlspecialchars($_POST['reason']) : null;
    $address = isset($_POST['address']) ? htmlspecialchars($_POST['address']) : null;
    $details = isset($_POST['details']) ? htmlspecialchars($_POST['details']) : null;
    $resolution = isset($_POST['resolution']) ? htmlspecialchars($_POST['resolution']) : null;

    if (empty($reason) || empty($address) || empty($details) || empty($resolution)) {
        echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO complaint_reports (reason, address, details, resolution) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $reason, $address, $details, $resolution);

    if ($stmt->execute()) {
        $report_id = $stmt->insert_id;
        $_SESSION['report_id'] = $report_id;  // Store sa session

        $notifStmt = $conn->prepare("INSERT INTO notifications (report_id, message, type, status) VALUES (?, ?, ?, ?)");
        $message = "A new complain report has been submitted.";
        $type = "Complain";
        $status = "unread";

        $notifStmt->bind_param("isss", $report_id, $message, $type, $status);
        $notifStmt->execute();
        $notifStmt->close();

        echo json_encode(['status' => 'success', 'message' => 'Report submitted successfully.', 'redirect' => 'contact-details.html']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to submit the report.']);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
?>
