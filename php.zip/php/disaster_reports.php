<?php
session_start(); // Start session para sa report_id
include_once 'config.php';

header('Content-Type: application/json');

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize form inputs
    $disasterType = isset($_POST['disasterType']) ? htmlspecialchars(trim($_POST['disasterType'])) : null;
    $address = isset($_POST['address']) ? htmlspecialchars(trim($_POST['address'])) : null;
    $details = isset($_POST['details']) ? htmlspecialchars(trim($_POST['details'])) : null;

    // Check for required fields
    if (empty($disasterType) || empty($address) || empty($details)) {
        echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
        exit;
    }

    // Prepare the SQL query
    $stmt = $conn->prepare("INSERT INTO disaster_reports (disasterType, address, details) VALUES (?, ?, ?)");
    if (!$stmt) {
        echo json_encode(['status' => 'error', 'message' => 'SQL error: ' . $conn->error]);
        exit;
    }

    $stmt->bind_param("sss", $disasterType, $address, $details);

    // Execute the query and check if it was successful
    if ($stmt->execute()) {
        // Kunin ang huling `report_id` at i-store sa session
        $report_id = $stmt->insert_id;
        $_SESSION['report_id'] = $report_id;  // Store sa session

        // Insert notification record
        $notifStmt = $conn->prepare("INSERT INTO notifications (report_id, message, type, status) VALUES (?, ?, ?, ?)");
        if (!$notifStmt) {
            echo json_encode(['status' => 'error', 'message' => 'SQL error: ' . $conn->error]);
            exit;
        }

        $message = "A new disaster report has been submitted.";
        $type = "Disaster";
        $status = "unread"; // Default status

        $notifStmt->bind_param("isss", $report_id, $message, $type, $status);

        if ($notifStmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Disaster report submitted successfully.', 'redirect' => 'ai2.html?report_id=']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to insert notification: ' . $notifStmt->error]);
        }

        $notifStmt->close();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to submit the disaster report: ' . $stmt->error]);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
