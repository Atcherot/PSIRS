<?php
$url = "http://192.168.8.104:8080/video";
header("Content-Type: image/jpeg");
readfile($url);
?>