<?php
// Include your database configuration
require 'config.php';

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the raw POST data
    $data = json_decode(file_get_contents("php://input"), true);

    // Check if camera and timestamp are set
    if (isset($data['camera'], $data['timestamp'])) {
        $camera = $data['camera'];
        $timestamp = $data['timestamp'];

        // Optional: Generate video URL if needed
        $video_url = "http://your-server.com/recordings/" . $camera . "_" . str_replace(['-', ':', 'T'], '', $timestamp) . ".mp4";

        // Insert into database (replace 'cctv_incidents' with your actual table name)
        $stmt = $conn->prepare("INSERT INTO cctv_incidents (camera_id, timestamp, video_url) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $camera, $timestamp, $video_url);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Incident reported successfully.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to report incident.']);
        }

        $stmt->close();
        $conn->close();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid data.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
?>
