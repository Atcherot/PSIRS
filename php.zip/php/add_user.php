<?php
// Include database connection (make sure to replace with actual database details)
include('config.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Hash password for security
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Prepare SQL query to insert the new user into the database
    $sql = "INSERT INTO users (first_name, last_name, email, password, role) 
            VALUES ('$firstName', '$lastName', '$email', '$hashedPassword', '$role')";

    // Execute the query
    if (mysqli_query($conn, $sql)) {
        // Redirect to users page with success message
        header("Location: users.php?success=User added successfully!");
        exit();
    } else {
        // Handle error
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>
