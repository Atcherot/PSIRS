<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include('config.php');

if (isset($_GET['id'])) {
    $reportId = $_GET['id'];

    if (!is_numeric($reportId)) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid report ID format.'
        ]);
        exit;
    }

    $query = "SELECT status FROM complaint_reports WHERE id = ?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("i", $reportId);
        $stmt->execute();
        $stmt->bind_result($status);

        if ($stmt->fetch()) {
            echo json_encode([
                'success' => true,
                'status' => $status
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Report not found.'
            ]);
        }

        $stmt->close();
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Database query failed.'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid report ID.'
    ]);
}
?>
