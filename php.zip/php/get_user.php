<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('config.php');

// Check if the 'id' parameter is provided
if (isset($_GET['id'])) {
    $userId = $conn->real_escape_string($_GET['id']);

    // Fetch user data based on the user ID
    $sql = "SELECT * FROM users WHERE id = '$userId'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch the data as an associative array and return it as JSON
        $user = $result->fetch_assoc();
        echo json_encode($user);
    } else {
        echo json_encode(['error' => 'User not found']);
    }
} else {
    echo json_encode(['error' => 'No user ID provided']);
}

// Close connection
$conn->close();
?>
