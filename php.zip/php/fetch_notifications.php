<?php
include_once 'config.php';

header('Content-Type: application/json');

// Kunin ang lahat ng unread notifications
$result = $conn->query("SELECT * FROM notifications WHERE status = 'unread' ORDER BY created_at DESC");

$notifications = [];
while ($row = $result->fetch_assoc()) {
    $notifications[] = $row;
}

echo json_encode($notifications);

$conn->close();
?>
