<?php
require __DIR__ . '/../vendor/autoload.php';

if (!class_exists('Dompdf\\Options')) {
    die("Dompdf\\Options class not found. Check autoload path or installation.");
}

use Dompdf\Dompdf;
use Dompdf\Options;

// Setup options
$options = new Options();
$options->set('defaultFont', 'Helvetica');
$dompdf = new Dompdf($options);

// Kunin ang ID at Category mula sa URL
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$category = isset($_GET['category']) ? $_GET['category'] : '';

// Connect sa Database
require 'config.php';

// Hanapin ang tamang table
$tables = [
    'Crime' => 'crime_reports',
    'Incident' => 'incident_reports',
    'Disaster' => 'disaster_reports',
    'Complain' => 'complaint_reports'
];

$table = $tables[$category] ?? null;

if (!$table) {
    die("Invalid category.");
}

// Kunin ang report
$query = "SELECT * FROM $table WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$report = $result->fetch_assoc();

if (!$report) {
    die("Report not found.");
}

// Create PDF content
$date = isset($report['reportDate']) ? $report['reportDate'] : 
        (isset($report['submitted_at']) ? $report['submitted_at'] : 
        (isset($report['reportedAt']) ? $report['reportedAt'] : 'N/A'));

$description = isset($report['description']) ? $report['description'] : 'No description available.';

$html = "
<h1 style='text-align: center;'>Report Details</h1>
<table border='1' cellspacing='0' cellpadding='8' style='width: 100%; border-collapse: collapse;'>
    <tr><td><strong>Category:</strong></td><td>{$category}</td></tr>
    <tr><td><strong>Report ID:</strong></td><td>{$report['id']}</td></tr>
    <tr><td><strong>Date:</strong></td><td>{$date}</td></tr>
    <tr><td><strong>Status:</strong></td><td>{$report['status']}</td></tr>
    <tr><td><strong>Description:</strong></td><td>{$description}</td></tr>
</table>
";

// Load HTML sa DOMPDF
$dompdf->loadHtml($html);

// Set paper size and orientation
$dompdf->setPaper('A4', 'portrait');

// Render the PDF (from HTML)
$dompdf->render();

// I-download ang PDF
$dompdf->stream("report_$id.pdf", ["Attachment" => false]);
?>