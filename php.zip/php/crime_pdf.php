<?php
require '../vendor/autoload.php';
use Dompdf\Dompdf;
use Dompdf\Options;

// Database connection
include('config.php');

if (isset($_GET['id'])) {
    $report_id = intval($_GET['id']);

    $query = "SELECT cr.*, r.first_name, r.last_name, r.phone_number FROM crime_reports cr LEFT JOIN reporters_crime r ON cr.id = r.report_id WHERE cr.id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $report_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Initialize Dompdf
        $options = new Options();
        $options->set('defaultFont', 'Arial');
        $dompdf = new Dompdf($options);

        // HTML content with table
        $html = "
            <h1 style='text-align: center;'>Crime Report</h1>
            <table border='1' cellspacing='0' cellpadding='8' style='width: 100%; border-collapse: collapse;'>
                <tr><td><strong>ID:</strong></td><td>{$row['id']}</td></tr>
                <tr><td><strong>Crime Type:</strong></td><td>{$row['crimeType']}</td></tr>
                <tr><td><strong>Address:</strong></td><td>{$row['address']}</td></tr>
                <tr><td><strong>Additional Info:</strong></td><td>{$row['additionalInfo']}</td></tr>
                <tr><td><strong>Report Date:</strong></td><td>{$row['reportDate']}</td></tr>
                <tr><td><strong>Status:</strong></td><td>{$row['status']}</td></tr>
            </table>
            <h2 style='text-align: center;'>Reporter Information</h2>
            <table border='1' cellspacing='0' cellpadding='8' style='width: 100%; border-collapse: collapse;'>
                <tr><td><strong>Name:</strong></td><td>{$row['first_name']} {$row['last_name']}</td></tr>
                <tr><td><strong>Phone Number:</strong></td><td>{$row['phone_number']}</td></tr>
            </table>
        ";

        // Load HTML and render PDF
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        $dompdf->stream("crime_report_{$row['id']}.pdf", ["Attachment" => false]);
    } else {
        echo "No report found.";
    }
} else {
    echo "Invalid request.";
}
?>