<?php
header('Content-Type: text/plain');

$servername = "localhost";  
$username = "publ_PSIRS";   
$password = "M1IOl+7Az3ArG5ld"; 
$dbname = "publ_incident_reporting_system"; 
$socket = '/run/mysqld/mysqld.sock';

$mysqli = new mysqli($servername, $username, $password, $dbname, null, $socket);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$report_id = isset($_GET['report_id']) ? intval($_GET['report_id']) : null;

if ($report_id) {
    $sql = "SELECT disasterType FROM disaster_type_logs WHERE report_id = ?";
    $stmt = $mysqli->prepare($sql);

    if (!$stmt) {
        echo "Error preparing statement: " . $mysqli->error;
        exit;
    }

    $stmt->bind_param("i", $report_id);

    if ($stmt->execute()) {
        $stmt->bind_result($disasterType);
        $stmt->fetch();
        $stmt->close();

        echo $disasterType ? "Disaster Type: $disasterType" : "Disaster type not found";

       $instructions = [
    'Typhoon' => "During a typhoon:\n
Step 1: Stay indoors and away from windows.\n
Step 2: Turn off gas and electricity if flooding occurs.\n
Step 3: Prepare emergency supplies (water, food, flashlight, first aid kit).\n
Step 4: Evacuate if advised by authorities.\n
After the storm:\n
Step 1: Avoid floodwaters and sharp debris.\n
Step 2: Check for injuries and administer first aid as needed.",

    'Earthquake' => "During an earthquake:\n
Step 1: Drop, Cover, and Hold On.\n
Step 2: Stay away from glass, heavy objects, and exterior walls.\n
Step 3: If outdoors, move to an open area away from buildings.\n
After the earthquake:\n
Step 1: Check for injuries and provide first aid.\n
Step 2: Avoid damaged buildings and structures.\n
Step 3: Be prepared for aftershocks.",

    'Hurricane' => "During a hurricane:\n
Step 1: Evacuate early if advised by authorities.\n
Step 2: Stay indoors in a small, windowless room.\n
Step 3: Secure all doors and windows.\n
After the hurricane:\n
Step 1: Avoid floodwaters and debris.\n
Step 2: Administer first aid to injured persons.\n
Step 3: Listen for emergency updates and instructions.",

    'Fire' => "During a fire:\n
Step 1: Evacuate immediately and stay low to avoid smoke.\n
Step 2: If clothing catches fire, Stop, Drop, and Roll.\n
Step 3: Call emergency services as soon as possible.\n
After the fire:\n
Step 1: Cool minor burns with water and cover with a clean cloth.\n
Step 2: Seek medical help for severe burns or smoke inhalation.",

    'Flood' => "During a flood:\n
Step 1: Move to higher ground immediately.\n
Step 2: Avoid walking or driving through floodwaters.\n
Step 3: Secure important documents and valuables.\n
After the flood:\n
Step 1: Disinfect wounds to prevent infection.\n
Step 2: Avoid debris and contaminated water.\n
Step 3: Stay informed through emergency updates."
];



        echo "\n" . ($instructions[$disasterType] ?? "No instructions available for this type.");
    } else {
        echo "Error executing statement: " . $stmt->error;
    }
} else {
    echo "No report ID provided.";
}

$mysqli->close();
?>
