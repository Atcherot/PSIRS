<?php
session_start(); // Start session para sa report_id
include 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $crimeType = isset($_POST['crimeType']) ? htmlspecialchars($_POST['crimeType']) : null;
    $address = isset($_POST['address']) ? htmlspecialchars($_POST['address']) : null;
    $additionalInfo = isset($_POST['additionalInfo']) ? htmlspecialchars($_POST['additionalInfo']) : null;

    if (empty($crimeType) || empty($address) || empty($additionalInfo)) {
        echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO crime_reports (crimeType, address, additionalInfo) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $crimeType, $address, $additionalInfo);

    if ($stmt->execute()) {
        $report_id = $stmt->insert_id;
        $_SESSION['report_id'] = $report_id;  // Store sa session

        $notifStmt = $conn->prepare("INSERT INTO notifications (report_id, message, type, status) VALUES (?, ?, ?, ?)");
        $message = "A new crime report has been submitted.";
        $type = "Crime";
        $status = "unread";

        $notifStmt->bind_param("isss", $report_id, $message, $type, $status);
        $notifStmt->execute();
        $notifStmt->close();

        echo json_encode(['status' => 'success', 'message' => 'Crime report submitted successfully.', 'redirect' => 'contact-details2.html']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to submit the crime report.']);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
