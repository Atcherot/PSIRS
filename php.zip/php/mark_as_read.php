<?php
include_once 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $notifId = intval($_POST['id']);

    $stmt = $conn->prepare("UPDATE notifications SET status = 'read' WHERE id = ?");
    $stmt->bind_param("i", $notifId);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Notification marked as read.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update notification status.']);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}
?>
