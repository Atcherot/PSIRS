
<?php
$servername = "localhost";  // Database server
$username = "publ_PSIRS";         // Database username
$password = "M1IOl+7Az3ArG5ld";             // Database password
$dbname = "publ_incident_reporting_system";  // Database name
$socket = '/run/mysqld/mysqld.sock';

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname, null, $socket);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
