<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('config.php');

// Check if form data is received
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $userId = $conn->real_escape_string($_POST['id']);
    $firstName = $conn->real_escape_string($_POST['firstName']);
    $lastName = $conn->real_escape_string($_POST['lastName']);
    $email = $conn->real_escape_string($_POST['email']);
    $role = $conn->real_escape_string($_POST['role']);
    
    // Optional: Password can be updated too, but typically it's updated separately
    // You can add password update logic here if necessary
    
    // Update query
    $sql = "UPDATE users 
            SET first_name = '$firstName', 
                last_name = '$lastName', 
                email = '$email', 
                role = '$role' 
            WHERE id = '$userId'";

    if ($conn->query($sql) === TRUE) {
        echo "User updated successfully!";
    } else {
        echo "Error updating user: " . $conn->error;
    }

    if (!empty($_POST['password'])) {
      $password = $conn->real_escape_string($_POST['password']);
      $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
      $sql = "UPDATE users 
              SET first_name = '$firstName', 
                  last_name = '$lastName', 
                  email = '$email', 
                  password = '$hashedPassword', 
                  role = '$role' 
              WHERE id = '$userId'";
  }
}  

// Close connection
$conn->close();
?>
