<?php
include 'config.php';

// Query to check for any new crime reports (You can modify this query per report type)
$query = "SELECT COUNT(*) as count FROM notifications WHERE status = 'unread'";  // Assuming there's a 'status' column
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

// Return the count of new reports as a JSON response
echo json_encode(['new_reports' => $row['count']]);
?>
