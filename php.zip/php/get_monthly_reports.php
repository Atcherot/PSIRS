<?php
include 'config.php';

// Function para makuha ang monthly data ng bawat table
function getMonthlyData($conn, $table) {
    $query = "
        SELECT 
            MONTHNAME(created_at) AS month, COUNT(*) AS count 
        FROM $table
        WHERE YEAR(created_at) = YEAR(CURDATE())
        GROUP BY MONTH(created_at)
        ORDER BY MONTH(created_at)
    ";
    $result = mysqli_query($conn, $query);

    $monthlyData = array_fill(0, 12, 0); // Default na array na may 12 zeroes (para sa bawat buwan)
    while ($row = mysqli_fetch_assoc($result)) {
        $monthIndex = date('n', strtotime($row['month'])) - 1;
        $monthlyData[$monthIndex] = (int)$row['count'];
    }

    return $monthlyData;
}

// Kumuha ng data mula sa bawat table
$crimeReports = getMonthlyData($conn, 'crime_reports');
$incidentReports = getMonthlyData($conn, 'incident_reports');
$disasterReports = getMonthlyData($conn, 'disaster_reports');
$complaintReports = getMonthlyData($conn, 'complaint_reports');

// I-combine ang lahat ng data sa isang JSON response
$response = [
    'crime_reports' => $crimeReports,
    'incident_reports' => $incidentReports,
    'disaster_reports' => $disasterReports,
    'complaint_reports' => $complaintReports
];

echo json_encode($response);
