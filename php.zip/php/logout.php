<?php
// logout.php - Destroy session and reset token
session_start();
session_unset();
session_destroy();
header('Location: ../index.html');
exit();
?>
