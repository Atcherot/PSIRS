<?php
// Start the session
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include the config.php file for database connection details
include('config.php');

// Logging function
function logMessage($message) {
    $logFile = 'login.log';
    $timestamp = date('Y-m-d H:i:s');
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    $logEntry = "[$timestamp] [IP: $ipAddress] $message" . PHP_EOL;
    file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
}

// Create connection using the values from config.php
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    logMessage("Connection failed: " . $conn->connect_error);
    die(json_encode(["status" => "error", "message" => "Connection failed"]));
}

// Handle POST request for login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the posted data (in JSON format)
    $data = json_decode(file_get_contents('php://input'), true);

    $email = $data['email'];
    $password = $data['password'];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        logMessage("Invalid email format: $email");
        echo json_encode(["status" => "error", "message" => "Invalid email format"]);
        exit();
    }

    // Prepare a statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    // Check if the user exists
    if ($stmt->num_rows === 0) {
        logMessage("Failed login attempt - User not found: $email");
        echo json_encode(["status" => "error", "message" => "User not found"]);
    } else {
        // User found, retrieve hashed password and role
        $stmt->bind_result($userId, $hashedPassword, $role);
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $hashedPassword)) {
            // Password is correct, login successful
            $token = bin2hex(random_bytes(32));  // Generate token
            $_SESSION['user_id'] = $userId; // Store user ID in session
            $_SESSION['token'] = $token; // Store token in session

            logMessage("Successful login - User ID: $userId, Role: $role");

            // Check if the role is admin
            if ($role === 'admin') {
                echo json_encode(["status" => "success", "message" => "Login successful", "token" => $token, "redirect_url" => "dashboard.php"]);
            } else {
                logMessage("Unauthorized role access attempt - User ID: $userId, Role: $role");
                echo json_encode(["status" => "error", "message" => "Unauthorized role"]);
            }
        } else {
            logMessage("Failed login attempt - Invalid password for User ID: $userId");
            echo json_encode(["status" => "error", "message" => "Invalid password"]);
        }
    }

    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>
