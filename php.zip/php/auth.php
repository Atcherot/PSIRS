<?php
// auth.php - Protect pages with token verification
session_start();

// Check if the user is logged in and has a valid token
if (!isset($_SESSION['user_id']) || !isset($_SESSION['token'])) {
    header('Location: admin-login.html');
    exit();
}

// Optionally, you can add a timeout mechanism here if needed
?>
