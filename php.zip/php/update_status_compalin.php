<?php
include('config.php');

if (isset($_GET['id'])) {
    $reportId = $_GET['id'];

    // I-update ang status sa "In Progress"
    $query = "UPDATE complaint_reports SET status = 'In Progress' WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $reportId);

    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(['success' => true, 'message' => 'Report status updated to In Progress.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update report status.']);
    }

    mysqli_stmt_close($stmt);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid report ID.']);
}
