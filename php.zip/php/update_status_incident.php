<?php
include('config.php');

if (isset($_GET['id'])) {
    $reportId = $_GET['id'];

    // Prepare the query to update the status of the report
    $query = "UPDATE incident_reports SET status = 'verified' WHERE id = ?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("i", $reportId);
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Report status updated to verified.'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Failed to update report status.'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Database query failed.'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid report ID.'
    ]);
}
?>
