<?php
session_start();
include 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_SESSION['report_id'])) {
        $report_id = $_SESSION['report_id'];
        $firstName = isset($_POST['firstName']) ? htmlspecialchars($_POST['firstName']) : null;
        $lastName = isset($_POST['lastName']) ? htmlspecialchars($_POST['lastName']) : null;
        $phone = isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : null;

        if (empty($firstName) || empty($lastName) || empty($phone)) {
            echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO reporters_incident (report_id, first_name, last_name, phone_number) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $report_id, $firstName, $lastName, $phone);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Contact details submitted successfully.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to submit contact details.']);
        }

        $stmt->close();
        $conn->close();
        unset($_SESSION['report_id']);  // Clear session after submission
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No report ID found.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
?>
