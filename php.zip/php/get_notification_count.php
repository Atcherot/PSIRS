<?php
include 'config.php';

// Query para makuha ang bilang ng unread notifications
$query = "SELECT COUNT(*) as count FROM notifications WHERE status = 'unread'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

// Ibalik bilang JSON
echo json_encode(['count' => $row['count']]);

mysqli_close($conn);
?>
