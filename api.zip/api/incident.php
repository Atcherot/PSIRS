<?php
// CORS headers to allow cross-origin requests
header("Access-Control-Allow-Origin: *"); // Allow any domain (replace with specific domain if needed)
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE"); // Allow these HTTP methods
header("Access-Control-Allow-Headers: Content-Type"); // Allow these headers (adjust as needed)

// Set content type to JSON
header('Content-Type: application/json');

// Include your database connection file
include '../php/config.php'; 

$method = $_SERVER['REQUEST_METHOD'];

// Function to handle SQL errors
function handleSQLError($conn, $message = 'Database query failed') {
    http_response_code(500);
    echo json_encode(['error' => $message, 'details' => $conn->error]);
    exit;
}

// Function to handle invalid input
function handleInvalidInput($message) {
    http_response_code(400);
    echo json_encode(['error' => $message]);
    exit;
}

// GET method: Fetch incident reports or a specific incident by ID
if ($method === 'GET') {
    $statusFilter = "'verified', 'in_progress', 'resolved', 'closed', 'rejected', 'on_hold', 'confirmed'";

    if (isset($_GET['status'])) {
        $status = $_GET['status'];
        $allowedStatuses = ['verified', 'in_progress', 'resolved', 'closed', 'rejected', 'on_hold', 'confirmed'];
        if (in_array($status, $allowedStatuses)) {
            $statusFilter = "'$status'";
        } else {
            handleInvalidInput('Invalid status provided');
        }
    }

    if (isset($_GET['id'])) {
        $incidentId = intval($_GET['id']);
        // JOIN incident_reports and reporters_incident
        $sql = "SELECT ir.id, ir.incident_type, ir.address, ir.details, ir.status, ir.submitted_at, 
                       ri.first_name AS reported_by, ri.phone_number 
                FROM incident_reports ir 
                LEFT JOIN reporters_incident ri ON ir.id = ri.report_id 
                WHERE ir.id = ? AND ir.status IN ($statusFilter)";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $incidentId);
        
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                echo json_encode($result->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(['message' => 'Incident not found']);
            }
        } else {
            handleSQLError($conn);
        }
        exit;
    }

    $sql = "SELECT ir.id, ir.incident_type, ir.address, ir.details, ir.status, ir.submitted_at, 
                   ri.first_name AS reported_by, ri.phone_number 
            FROM incident_reports ir 
            LEFT JOIN reporters_incident ri ON ir.id = ri.report_id 
            WHERE ir.status IN ($statusFilter)";
    
    $result = $conn->query($sql);
    if ($result) {
        echo json_encode($result->fetch_all(MYSQLI_ASSOC));
    } else {
        handleSQLError($conn);
    }
    exit;
}




// POST method: Create a new incident report
if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    // Validate input data
    if (!isset($data['incident_type'], $data['address'], $data['details'], $data['first_name'], $data['last_name'], $data['phone_number'])) {
        handleInvalidInput('Missing required fields: incident_type, address, details, first_name, last_name, phone_number');
    }

    // Start a transaction
    $conn->begin_transaction();

    try {
        // Insert into incident_reports table
        $sql = "INSERT INTO incident_reports (incident_type, address, details, status, submitted_at) VALUES (?, ?, ?, 'pending', NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('sss', $data['incident_type'], $data['address'], $data['details']);
        
        if (!$stmt->execute()) {
            throw new Exception($conn->error);
        }

        $incidentId = $conn->insert_id;

        // Insert into reporters_incident table
        $sql = "INSERT INTO reporters_incident (report_id, first_name, last_name, phone_number) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('isss', $incidentId, $data['first_name'], $data['last_name'], $data['phone_number']);
        
        if (!$stmt->execute()) {
            throw new Exception($conn->error);
        }

        // Commit transaction
        $conn->commit();
        echo json_encode(['message' => 'Incident and reporter details created successfully', 'id' => $incidentId]);
    } catch (Exception $e) {
        $conn->rollback();
        handleSQLError($conn, $e->getMessage());
    }
    exit;
}




// PUT method: Update the status of an existing incident report
if ($method === 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);
    // Validate input data
    if (!isset($data['status'], $data['id'])) {
        handleInvalidInput('Missing required fields: status, id');
    }

    $sql = "UPDATE incident_reports SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('si', $data['status'], $data['id']);
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['message' => 'Status updated successfully']);
        } else {
            http_response_code(404);
            echo json_encode(['message' => 'Incident not found']);
        }
    } else {
        handleSQLError($conn);
    }
    exit;
}



// DELETE method: Delete an incident report by ID
if ($method === 'DELETE') {
    $data = json_decode(file_get_contents('php://input'), true);
    // Validate input data
    if (!isset($data['id'])) {
        handleInvalidInput('Missing required field: id');
    }

    $sql = "DELETE FROM incident_reports WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $data['id']);
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['message' => 'Incident deleted successfully']);
        } else {
            http_response_code(404);
            echo json_encode(['message' => 'Incident not found']);
        }
    } else {
        handleSQLError($conn);
    }
    exit;
}
?>
