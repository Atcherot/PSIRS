<?php
// CORS headers to allow cross-origin requests
header("Access-Control-Allow-Origin: *"); // Allow any domain (replace with specific domain if needed)
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE"); // Allow these HTTP methods
header("Access-Control-Allow-Headers: Content-Type"); // Allow these headers (adjust as needed)

// Set content type to JSON
header('Content-Type: application/json');

// Include your database connection file
include '../php/config.php'; 

$method = $_SERVER['REQUEST_METHOD'];

// Function to handle SQL errors
function handleSQLError($conn, $message = 'Database query failed') {
    http_response_code(500);
    echo json_encode(['error' => $message, 'details' => $conn->error]);
    exit;
}

// Function to handle invalid input
function handleInvalidInput($message) {
    http_response_code(400);
    echo json_encode(['error' => $message]);
    exit;
}

// GET method: Fetch complaint reports or a specific complaint by ID
if ($method === 'GET') {
    $statusFilter = "'verified', 'in_progress', 'resolved', 'closed', 'rejected', 'on_hold', 'confirmed'";

    if (isset($_GET['status'])) {
        $status = $_GET['status'];
        $allowedStatuses = ['verified', 'in_progress', 'resolved', 'closed', 'rejected', 'on_hold', 'confirmed'];
        if (in_array($status, $allowedStatuses)) {
            $statusFilter = "'$status'";
        } else {
            handleInvalidInput('Invalid status provided');
        }
    }

    if (isset($_GET['id'])) {
        $complaintId = intval($_GET['id']);
        // JOIN complaint_reports and reporters
        $sql = "SELECT cr.id, cr.reason, cr.address, cr.details, cr.status, cr.resolution, cr.submitted_at, 
                       rc.first_name AS reported_by, rc.phone_number 
                FROM complaint_reports cr 
                LEFT JOIN reporters rc ON cr.id = rc.report_id 
                WHERE cr.id = ? AND cr.status IN ($statusFilter)";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $complaintId);
        
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                echo json_encode($result->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(['message' => 'Complaint not found']);
            }
        } else {
            handleSQLError($conn);
        }
        exit;
    }

    $sql = "SELECT cr.id, cr.reason, cr.address, cr.details, cr.status, cr.resolution, cr.submitted_at, 
                   rc.first_name AS reported_by, rc.phone_number 
            FROM complaint_reports cr 
            LEFT JOIN reporters rc ON cr.id = rc.report_id 
            WHERE cr.status IN ($statusFilter)";
    
    $result = $conn->query($sql);
    if ($result) {
        echo json_encode($result->fetch_all(MYSQLI_ASSOC));
    } else {
        handleSQLError($conn);
    }
    exit;
}

// POST method: Create a new complaint report
if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    // Validate input data
    if (!isset($data['reason'], $data['address'], $data['details'], $data['resolution'], $data['first_name'], $data['last_name'], $data['phone_number'])) {
        handleInvalidInput('Missing required fields: reason, address, details, resolution, first_name, last_name, phone_number');
    }

    // Start a transaction
    $conn->begin_transaction();

    try {
        // Insert into complaint_reports table
        $sql = "INSERT INTO complaint_reports (reason, address, details, resolution, submitted_at) VALUES (?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ssss', $data['reason'], $data['address'], $data['details'], $data['resolution']);
        
        if (!$stmt->execute()) {
            throw new Exception($conn->error);
        }

        $complaintId = $conn->insert_id;

        // Insert into reporters table
        $sql = "INSERT INTO reporters (report_id, first_name, last_name, phone_number) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('isss', $complaintId, $data['first_name'], $data['last_name'], $data['phone_number']);
        
        if (!$stmt->execute()) {
            throw new Exception($conn->error);
        }

        // Commit transaction
        $conn->commit();
        echo json_encode(['message' => 'Complaint and reporter details created successfully', 'id' => $complaintId]);
    } catch (Exception $e) {
        $conn->rollback();
        handleSQLError($conn, $e->getMessage());
    }
    exit;
}

// PUT method: Update the status of an existing complaint report
if ($method === 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);
    // Validate input data
    if (!isset($data['status'], $data['id'])) {
        handleInvalidInput('Missing required fields: status, id');
    }

    $sql = "UPDATE complaint_reports SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('si', $data['status'], $data['id']);
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['message' => 'Status updated successfully']);
        } else {
            http_response_code(404);
            echo json_encode(['message' => 'Complaint not found']);
        }
    } else {
        handleSQLError($conn);
    }
    exit;
}

// DELETE method: Delete a complaint report by ID
if ($method === 'DELETE') {
    $data = json_decode(file_get_contents('php://input'), true);
    // Validate input data
    if (!isset($data['id'])) {
        handleInvalidInput('Missing required field: id');
    }

    $sql = "DELETE FROM complaint_reports WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $data['id']);
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['message' => 'Complaint deleted successfully']);
        } else {
            http_response_code(404);
            echo json_encode(['message' => 'Complaint not found']);
        }
    } else {
        handleSQLError($conn);
    }
    exit;
}
?>
