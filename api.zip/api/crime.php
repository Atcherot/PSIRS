<?php
// CORS headers to allow cross-origin requests
header("Access-Control-Allow-Origin: *"); // Allow any domain (replace with specific domain if needed)
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE"); // Allow these HTTP methods
header("Access-Control-Allow-Headers: Content-Type"); // Allow these headers (adjust as needed)

// Set content type to JSON
header('Content-Type: application/json');

// Include your database connection file
include '../php/config.php'; 

$method = $_SERVER['REQUEST_METHOD'];

// Function to handle SQL errors
function handleSQLError($conn, $message = 'Database query failed') {
    http_response_code(500);
    echo json_encode(['error' => $message, 'details' => $conn->error]);
    exit;
}

// Function to handle invalid input
function handleInvalidInput($message) {
    http_response_code(400);
    echo json_encode(['error' => $message]);
    exit;
}

// GET method: Fetch crime reports or a specific crime by ID
if ($method === 'GET') {
    $statusFilter = "'verified', 'in_progress', 'resolved', 'closed', 'rejected', 'on_hold', 'confirmed'";

    if (isset($_GET['status'])) {
        $status = $_GET['status'];
        $allowedStatuses = ['verified', 'in_progress', 'resolved', 'closed', 'rejected', 'on_hold', 'confirmed'];
        if (in_array($status, $allowedStatuses)) {
            $statusFilter = "'$status'";
        } else {
            handleInvalidInput('Invalid status provided');
        }
    }

    if (isset($_GET['id'])) {
        $crimeId = intval($_GET['id']);
        $sql = "SELECT cr.id, cr.crimeType, cr.address, cr.additionalInfo, cr.status, cr.reportDate, 
                       rc.first_name AS reported_by, rc.phone_number 
                FROM crime_reports cr 
                LEFT JOIN reporters_crime rc ON cr.id = rc.report_id 
                WHERE cr.id = ? AND cr.status IN ($statusFilter)";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $crimeId);

        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                echo json_encode($result->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(['message' => 'Crime not found']);
            }
        } else {
            handleSQLError($conn);
        }
        exit;
    }

    $sql = "SELECT cr.id, cr.crimeType, cr.address, cr.additionalInfo, cr.status, cr.reportDate, 
                   rc.first_name AS reported_by, rc.phone_number 
            FROM crime_reports cr 
            LEFT JOIN reporters_crime rc ON cr.id = rc.report_id 
            WHERE cr.status IN ($statusFilter)";

    $result = $conn->query($sql);
    if ($result) {
        echo json_encode($result->fetch_all(MYSQLI_ASSOC));
    } else {
        handleSQLError($conn);
    }
    exit;
}

// POST method: Create a new crime report
if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['crimeType'], $data['address'], $data['additionalInfo'], $data['first_name'], $data['last_name'], $data['phone_number'])) {
        handleInvalidInput('Missing required fields: crimeType, address, additionalInfo, first_name, last_name, phone_number');
    }

    $conn->begin_transaction();
    try {
        $sql = "INSERT INTO crime_reports (crimeType, address, additionalInfo, status, reportDate) VALUES (?, ?, ?, 'pending', NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('sss', $data['crimeType'], $data['address'], $data['additionalInfo']);

        if (!$stmt->execute()) {
            throw new Exception($conn->error);
        }

        $crimeId = $conn->insert_id;

        $sql = "INSERT INTO reporters_crime (report_id, first_name, last_name, phone_number) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('isss', $crimeId, $data['first_name'], $data['last_name'], $data['phone_number']);

        if (!$stmt->execute()) {
            throw new Exception($conn->error);
        }

        $conn->commit();
        echo json_encode(['message' => 'Crime and reporter details created successfully', 'id' => $crimeId]);
    } catch (Exception $e) {
        $conn->rollback();
        handleSQLError($conn, $e->getMessage());
    }
    exit;
}

// PUT method: Update crime report status
if ($method === 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['status'], $data['id'])) {
        handleInvalidInput('Missing required fields: status, id');
    }

    $sql = "UPDATE crime_reports SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('si', $data['status'], $data['id']);
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['message' => 'Crime report status updated successfully']);
        } else {
            http_response_code(404);
            echo json_encode(['message' => 'Crime not found']);
        }
    } else {
        handleSQLError($conn);
    }
    exit;
}

// DELETE method: Delete a crime report by ID
if ($method === 'DELETE') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!isset($data['id'])) {
        handleInvalidInput('Missing required field: id');
    }

    $sql = "DELETE FROM crime_reports WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $data['id']);
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['message' => 'Crime report deleted successfully']);
        } else {
            http_response_code(404);
            echo json_encode(['message' => 'Crime not found']);
        }
    } else {
        handleSQLError($conn);
    }
    exit;
}
?>
